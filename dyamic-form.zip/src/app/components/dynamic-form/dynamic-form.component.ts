import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import {fieldInfo} from '../../app.component';
@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.css']
})



export class DynamicFormComponent implements OnInit {
  
  @Input() config = {} as fieldInfo;
  @Input() globalConfig = {} as fieldInfo;
  @Input() parentFormGroup!:FormGroup;
  @Input() FormGroupIndex!:number;
  @Input() submitted:boolean = false;

  public configObj:any = {}
  constructor(private formBuilder: FormBuilder) {}
  
  ngOnInit(): void {
    this.parentFormGroup = this.createForm(this.config, this.parentFormGroup);
  }

  getfg(val:any) : FormGroup{
    return val as FormGroup
  }

  createForm(config:fieldInfo, formGroup:FormGroup) {
    config.fieldList?.forEach((field:fieldInfo) => {

      if(field['type'] != 'section')
      {
        formGroup.addControl(field['name'], new FormControl("",[]))

        
        let validationArray:Array<any>= [];

        field['validation']?.forEach((validation) => {
         
          
          if(validation == 'required'){
            validationArray.push(Validators.required)
          }else if(validation == 'email'){
            validationArray.push(Validators.email)
          }else if(validation == 'phone'){
            validationArray.push(Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$"))
          }
          
        })
        formGroup.controls[field['name']].setValidators(validationArray)
        

        formGroup.controls[field['name']].updateValueAndValidity()
       }else if((field['type'] == 'section') && field['repeatable']){
        
        formGroup.addControl(field['name'], this.formBuilder.array([this.createForm(field, new FormGroup({}))])as FormArray)
      }
      else if((field['type'] == 'section') && !field['repeatable']){
        formGroup.addControl(field['name'], this.createForm(field, new FormGroup({})))
      } 
    })

    return formGroup;
  }

 
  getDependentFields(field: fieldInfo, index:number): void{
    
      let data = this.parentFormGroup.get(field['name']) as FormControl;

      let obj = {
        name: field?.['name'],
        fieldList : data['value'] ? field['dependendFields'][data['value']] : []
      };

      this.configObj[index] = this.configObj[index] ? this.configObj[index] : this.config
      
      let old = this.configObj[index].fieldList;
      let backup = this.getInfoFromGlobalConfig(this.configObj[index], this.globalConfig)
     
      this.configObj[index]['fieldList'] = JSON.parse(JSON.stringify(backup['fieldList']));
      let newVal = JSON.parse(JSON.stringify(this.configObj[index].fieldList))
      let diff = old.filter((item1:fieldInfo) =>  !newVal.some((item2:fieldInfo) => (item2.name === item1.name)))
      
      
      diff.forEach((res:fieldInfo) => {
         this.parentFormGroup.removeControl(res['name'])
      })
     
       field['dependendFields']?.[data['value']]?.forEach((res:fieldInfo) => {
       this.configObj[index].fieldList.push(res)
      }) 

      this.parentFormGroup =  this.createForm(obj, this.parentFormGroup)
   
 }

  addBeneficiary = (field:fieldInfo, index:number):void => {
    let fieldBackup = this.globalConfig.fieldList?.filter((res:fieldInfo) => res['name'] == field['name'])
    this.configObj[++index] = JSON.parse(JSON.stringify(fieldBackup?.[0])); 
    let data = this.parentFormGroup.get(field['name']) as FormArray;
    data.push(new FormGroup({}))
  }

  deleteBeneficiary = (field:fieldInfo, index:number):void => {
    let data = this.parentFormGroup.get(field['name']) as FormArray;
    data.removeAt(index)
  }


  getControl = (fg:FormGroup, field:fieldInfo): FormArray => {
    
    return fg.get(field['name']) as FormArray;
  }

  getFormGroup = (field:fieldInfo):FormGroup => {
    return this.parentFormGroup.get(field['name']) as FormGroup;
  }

  getError = (field:fieldInfo): FormControl => {
   
   return this.parentFormGroup.get(field['name']) as FormControl;
  }

 getInfoFromGlobalConfig = (config:any,globalConfig:fieldInfo) => {
    let response = {} as fieldInfo;
    globalConfig.fieldList?.forEach((res) => {
      if(res['name'] == config['name']){
          response =  res;
        
      }
    })
    return response;
  }

}
