import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

export interface fieldInfo
{
  name: string,
  label?: string
  type?: string,
  repeatable?:boolean,
  fieldList?: fieldInfo[],
  values?:dropdownValues[],
  dependendFields?:any,
  validation?:Array<string>
}

export interface dropdownValues{
  displayValue:string,
  actualValue:string
}

 @Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})




export class AppComponent{

  public myForm: FormGroup= new FormGroup({});
  public globalConfig = {} as fieldInfo;;
  public config = {} as fieldInfo;
  public submitted: boolean = false;

  constructor(private http:HttpClient){}
  
  ngOnInit():void{

    this.http.get<fieldInfo>('assets/data/config.json').subscribe((config) => {
      this.config = config;
      this.globalConfig = JSON.parse(JSON.stringify(this.config));
    })
    
  }

  ngAfterViewInit(){
    
  }

  onSubmit():void{
   
    this.submitted = true;
    console.log("yes",this.myForm.value)
  }
}



